import time
from pymodbus.client.sync import ModbusSerialClient as ModbusClient

class AGGripperControl():
    # for pymodbus 2.5.3 ubuntu
    def __init__(self,method='rtu',
        port='/dev/ttyUSB0', 
        baudrate=115200,
        stopbits=1,
        bytesize=8,
        parity='N',
        timeout=1,
        retries=5
    ):
        ...

    def dh_init(self,is_init):
        ...

    
    def control_gripper(self,cmd):
        ...


if __name__ == '__main__':
    dh_client=AGGripperControl()
    dh_client.dh_init(True)
    while True:
        print("请输入指令： cmd: num  a:结束")
        cmd = input()
        if cmd == 'a':
            break
        else:
            dh_client.control_gripper(int(cmd))



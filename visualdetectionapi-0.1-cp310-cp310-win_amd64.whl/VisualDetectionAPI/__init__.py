# VisualDetectionAPI/__init__.py

from .classifier_model import classifier
from .obj_bounding_box_utils import ObjBoundingBox
from .rotated_bounding_box_utils import RotatedBoundingBox
from .tool import (
    CameraInfo,
    create_point_cloud_from_depth_image,
    pose_robot as tool_pose_robot,
    extract_point_cloud_in_region,
    save_origin_roi_pointCloud_files,
    knn_cluster,
    depthMeasure,
    depth_measure_point_cloud,
    getDualArmCameraWorldPose,
    transformDualArmEyeIn,
    transformDualArmEyeTo,
    is_point_in_rect,
    filter_obj_flag,
    MyThread,
    draw_rectangle_on_image,
)
from .tool_gripper_tranform_utils import (
    pose_robot as gripper_pose_robot,
    apply_gripper_rotation
)

pose_robot = tool_pose_robot
gripper_pose_robot = gripper_pose_robot

# 定义接口
__all__ = [
    # 分类
    'classifier',

    # 边界框相关类
    'ObjBoundingBox',
    'RotatedBoundingBox',

    # 相机与点云工具类和函数
    'CameraInfo',
    'create_point_cloud_from_depth_image',
    'extract_point_cloud_in_region',
    'save_origin_roi_pointCloud_files',
    'knn_cluster',
    'depthMeasure',
    'depth_measure_point_cloud',
    'getDualArmCameraWorldPose',
    'transformDualArmEyeIn',
    'transformDualArmEyeTo',
    'is_point_in_rect',
    'filter_obj_flag',
    'MyThread',
    'draw_rectangle_on_image',

    # 工具函数（注意区分来源）
    'pose_robot',
    'gripper_pose_robot',
    'apply_gripper_rotation',
]






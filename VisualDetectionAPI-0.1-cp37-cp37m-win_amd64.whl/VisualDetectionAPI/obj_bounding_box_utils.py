import math
import cv2
import numpy as np
from typing import List, Optional, Tuple

class ObjBoundingBox:
    def __init__(self, xyxy, score, label, center_height=None):
        """
        表示检测到的目标边界框的对象。

        Args:
            xyxy (tuple or list of int): 边界框坐标，格式为 (x0, y0, x1, y1)
            score (float): 检测置信度分数，范围 [0, 1]
            label (str or int): 检测目标的类别标签（字符串或整数）
            center_height (float or None, optional): 目标中心的高度值（用于 3D 信息），默认为 None
        """
        ...

    def print_variables(self):
        """

        Returns:

        """
        ...

    def draw_box(self, image, color=(0, 255, 0), thickness=2, label_color=(255, 255, 255), show_label=True):
        """
        在图像上绘制边界框
        
        参数:
            image: 要绘制框的图像 (numpy数组)
            color: 框的颜色 (BGR格式，默认绿色)
            thickness: 框线粗细 (默认2)
            label_color: 标签文字颜色 (BGR格式，默认白色)
            show_label: 是否显示标签和置信度 (默认True)
        """
        ...

    def draw_center_point(self, image, color=(0, 0, 255), radius=3, thickness=-1):
        """
        在图像上绘制中心点
        
        参数:
            image: 要绘制点的图像 (numpy数组)
            color: 点的颜色 (BGR格式，默认红色)
            radius: 点的半径 (默认3)
            thickness: 点粗细 (-1表示填充，默认-1)
        """
        ...

    def draw_mask(self, image, color=(0, 255, 0), alpha=0.3):
        """
        在图像上绘制遮罩区域 (如果有mask_region)
        
        参数:
            image: 要绘制遮罩的图像 (numpy数组)
            color: 遮罩颜色 (BGR格式，默认绿色)
            alpha: 透明度 (0-1之间，默认0.3)
        """
        ...

    def extract_rgb_region(self,image: np.ndarray):
        """
        根据检测框的范围提取图像区域并存储到self.rgb_region
        
        参数:
            image: 输入的RGB/BGR图像 (numpy数组)
            
        返回:
            bool: 是否成功提取区域
        """
        ...
        

    @staticmethod
    def draw_obj_boxes(
        img: np.ndarray,
        bboxes: List['ObjBoundingBox'],
        *,
        show_center: bool = True,
        show_labels: bool = True,
        show_masks: bool = False,
        color_palette: Optional[dict] = None,
        display: bool = False,
        window_name: str = 'Bounding Box Visualization',
        delay: int = 1000
    ) -> np.ndarray:
        """
        
        参数:
            img: 输入图像 (BGR格式)
            bboxes: ObjBoundingBox 对象列表
            show_center: 是否显示中心点 (默认True)
            show_labels: 是否显示标签和置信度 (默认True)
            show_masks: 是否显示遮罩 (默认True)
            color_palette: 自定义颜色字典 {label: (B,G,R)}
            display: 是否显示图像 (默认False)
            window_name: 显示窗口名称 (默认'Bounding Box Visualization')
            delay: 显示延迟ms (0=等待按键, 默认0)
            
        返回:
            绘制了边界框的图像副本 (BGR格式)
        """
        ...
    
    @staticmethod
    def sort_boxes_by_center(
        bboxes,
        order = 'x',
        reverse = False
    ):
        """

        参数:
            bboxes: 要排序的边界框列表
            order: 排序方式，可选:
                'x' - 按x坐标排序
                'y' - 按y坐标排序
                'xy' - 先按x再按y排序
                'yx' - 先按y再按x排序
            reverse: 是否降序排序 (默认False，即升序)
            
        返回:
            排序后的边界框列表
        """
        ...


if __name__ == '__main__':
    # 示例使用
    bbox = ObjBoundingBox(xyxy=(100, 100, 200, 200), score=0.95, label="person")

    # 创建一个空白图像 (假设是BGR格式)
    image = np.zeros((300, 300, 3), dtype=np.uint8)

    # 绘制边界框
    image = bbox.draw_box(image)

    # 绘制中心点
    image = bbox.draw_center_point(image)

    # 显示图像
    cv2.imshow("Bounding Box", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
















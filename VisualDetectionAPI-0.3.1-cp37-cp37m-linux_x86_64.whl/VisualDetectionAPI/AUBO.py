import time
import math
import pyaubo_sdk

M_PI = 3.14159265358979323846

class AuboRobot():
    def __init__(self,robot_ip="192.168.1.12"):
        ...

    def init_connect(self):
        ...

    def getTcpRadPose(self):
        ...

    def getTcpAnglePose(self):
        ...

    def getJointPositionsRad(self):
        ...

    def getJointPositionsAngle(self):
        ...

    def getJointSpeeds(self):
        ...
        
    def getToolPose(self):
        ...

    def getTcpTargetPose(self):
        ...

    def getTcpTargetSpeed(self):
        ...

    def isWithinSafetyLimits(self):
        ...

    def isSteady(self):
        ...

    def getRobotModeType(self):
        ...

    def getTcpSpeed(self):
        ...


    def example_movel_angle(self,move_pose,acc=0.8,speed=0.15,radius=0,time=0):
        ...

    def example_movel_rad(self,move_pose,acc=0.8,speed=0.15,radius=0,time=0):
        ...

    def exampleInverseK(self,cert_rad,ref_joints):
        ...

    def example_movej(self,joint_pose):
        # 关节角，单位: 弧度
        ...


    def example_servoj_cert_angle(self,cert_angle):
        ...

    def dis_connect(self):
        ...

if __name__ == '__main__':
    robot=AuboRobot("169.254.4.70")
    angle_cert_pose=robot.getTcpAnglePose()

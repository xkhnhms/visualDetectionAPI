# VisualDetectionAPI/__init__.py

from .classifier_model import classifier
from .obj_bounding_box_utils import ObjBoundingBox
from .rotated_bounding_box_utils import RotatedBoundingBox
from .tool import (
    CameraInfo,
    create_point_cloud_from_depth_image,
    pose_robot as tool_pose_robot,
    extract_point_cloud_in_region,
    save_origin_roi_pointCloud_files,
    knn_cluster,
    depthMeasure,
    depth_measure_point_cloud,
    getDualArmCameraWorldPose,
    transformDualArmEyeIn,
    transformDualArmEyeTo,
    is_point_in_rect,
    filter_obj_flag,
    MyThread,
    draw_rectangle_on_image,
)
from .tool_gripper_tranform_utils import (
    pose_robot as gripper_pose_robot,
    apply_gripper_rotation
)

# 如果你想统一导出一个 pose_robot 函数，可以选择别名处理
# 这里我们保留两个不同来源的 pose_robot，避免冲突
pose_robot = tool_pose_robot
gripper_pose_robot = gripper_pose_robot

# 定义对外暴露的接口
__all__ = [
    # 分类模型
    'classifier',

    # 边界框相关类
    'ObjBoundingBox',
    'RotatedBoundingBox',

    # 相机与点云工具类和函数
    'CameraInfo',
    'create_point_cloud_from_depth_image',
    'extract_point_cloud_in_region',
    'save_origin_roi_pointCloud_files',
    'knn_cluster',
    'depthMeasure',
    'depth_measure_point_cloud',
    'getDualArmCameraWorldPose',
    'transformDualArmEyeIn',
    'transformDualArmEyeTo',
    'is_point_in_rect',
    'filter_obj_flag',
    'MyThread',
    'draw_rectangle_on_image',

    # 工具函数（注意区分来源）
    'pose_robot',                # 来自 tool 模块
    'gripper_pose_robot',        # 来自 tool_gripper_tranform_utils 模块
    'apply_gripper_rotation',
]






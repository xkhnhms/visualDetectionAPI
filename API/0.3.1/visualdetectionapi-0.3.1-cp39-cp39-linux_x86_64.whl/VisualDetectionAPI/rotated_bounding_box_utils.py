import math
from scipy.interpolate import griddata
import cv2
import numpy as np
import open3d as o3d

class RotatedBoundingBox:
    def __init__(self, xywhr, score, label, center_height=None):
        """
       表示一个旋转边界框的对象。

       旋转边界框格式为 (center_x, center_y, width, height, rotation_angle)，其中：
       - (center_x, center_y) 是边界框中心坐标
       - width 和 height 分别是边界框的宽和高
       - rotation_angle 是绕中心点旋转的角度（单位：度或弧度，视具体模型而定）

       Args:
           xywhr (tuple or list of float): 旋转边界框参数，格式为 (center_x, center_y, width, height, rotation)
           score (float): 检测置信度分数，范围 [0, 1]
           label (str or int): 目标类别标签（字符串或整数）
           center_height (float or None, optional): 中心点高度信息（可用于三维空间定位），默认为 None
       """

        ...



    def print_variables(self):
        '''

        Returns:

        '''
        ...

    def draw_rotated_box(self, img, color=(0, 255, 0), thickness=2):
        ...

    def draw_rotated_box_with_center(self, img, color_box=(0, 255, 0), color_center=(0, 0, 255), thickness=2):
        '''

        Args:
            img ():
            color_box ():
            color_center ():
            thickness ():

        Returns:

        '''
        ...

    def get_width_direction_vector(self):
        ...
    
    def get_side_distances(self, other_boxes):
        '''

        Args:
            other_boxes ():

        Returns:

        '''
        ...


    def get_min_side_gap(self, other_boxes):
        '''

        Args:
            other_boxes ():

        Returns:

        '''
        ...

    @staticmethod
    def sort_by_min_side_gap(boxes, descending=True):
        '''

        Args:
            boxes ():
            descending ():

        Returns:

        '''
        ...

    def calculate_mse_with(self, other_bbox):
        '''

        Args:
            other_bbox ():

        Returns:

        '''
        ...

    @staticmethod
    def find_best_match_by_bbox(current_bbox_pre, bbox_list):
        '''

        Args:
            current_bbox_pre ():
            bbox_list ():

        Returns:

        '''
        ...


    @staticmethod
    def draw_rotated_boxes(img,bboxes):
        '''

        Args:
            img ():
            bboxes ():

        Returns:

        '''
        ...

    def is_point_inside_by_step(self, px, py):
        '''

        Args:
            px ():
            py ():

        Returns:

        '''
        ...


    def calculate_near_points_step(self, long_step, short_step):
        '''

        Args:
            long_step ():
            short_step ():

        Returns:

        '''
        ...

    def is_point_inside(self, px, py):
        '''

        Args:
            px ():
            py ():

        Returns:

        '''
        ...

    def calculate_near_points(self, near_x, near_y):
        '''

        Args:
            near_x ():
            near_y ():

        Returns:

        '''
        ...

    def compute_normal_and_angle(self, isShow=False):
        '''

        Args:
            isShow ():

        Returns:

        '''
        ...



    def compute_normal_and_angle_with_gradient(self, isShow=False):
        '''

        Args:
            isShow ():

        Returns:

        '''

        ...

    def calculate_boundary_points(self):
        '''

        Returns:

        '''
        ...

    def create_mask(self, img_shape):
        '''

        Args:
            img_shape ():

        Returns:

        '''
        ...

    def set_mask_region(self, img_shape):
        '''

        Args:
            img_shape ():

        Returns:

        '''
        ...


    def extract_point_cloud(self, depth_frame, camera_intrinsics, shrink_ratio=0.0):
        '''

        Args:
            depth_frame ():
            camera_intrinsics ():
            shrink_ratio ():

        Returns:

        '''
        ...


    def extract_point_cloud_by_lr(self, depth_frame, camera_intrinsics,flag='left,right'):
        '''

        Args:
            depth_frame ():
            camera_intrinsics ():
            flag ():

        Returns:

        '''
        ...

    def extract_point_cloud_region(self, point_cloud):
        '''

        Args:
            point_cloud ():

        Returns:

        '''
        ...

    def extract_point_cloud_region_with_shrink(self, point_cloud, shrink_ratio=0.0):
        '''

        Args:
            point_cloud ():
            shrink_ratio ():

        Returns:

        '''
        ...


    def extract_rgb_rotated_region(self, img, visualize=True):
        '''

        Args:
            img ():
            visualize ():

        Returns:

        '''
        ...


    def is_center_in_quarter_area(self, img_shape,quarter_ratio_x=0.75,quarter_ratio_y=0.75):
        """

        Args:
            img_shape (Tuple[int, int]): 图像的尺寸，格式为 (height, width)
            quarter_ratio_x (float, optional): 图像宽度方向上的阈值比例，默认为 0.75
            quarter_ratio_y (float, optional): 图像高度方向上的阈值比例，默认为 0.75

        Returns:
            bool: 如果边界框的中心点位于指定区域外，返回 True；否则返回 False

        """
        ...

    def is_center_in_specified_area(self, top_left, bottom_right, proportion):
        '''

        Args:
            top_left ():
            bottom_right ():
            proportion ():

        Returns:

        '''
        ...

    def is_rotation_within_angle_range(self, min_angle, max_angle):
        '''

        Args:
            min_angle ():
            max_angle ():

        Returns:

        '''
        # Normalize the angles to be within 0 to 360 degrees
        ...

    @staticmethod
    def filter_bboxes_by_angle_range(bboxes, min_angle, max_angle):
        '''

        Args:
            bboxes ():
            min_angle ():
            max_angle ():

        Returns:

        '''
        ...

    def get_properties(self):
        '''

        Returns:

        '''
        ...

    @staticmethod
    def append_boxes(boxes):
        '''

        Args:
            boxes ():

        Returns:

        '''
        ...

    @staticmethod
    def append_boxes2(boxes):
        '''

        Args:
            boxes ():

        Returns:

        '''
        ...

    @staticmethod
    def sort_by_score(boxes):
        '''

        Args:
            boxes ():

        Returns:

        '''
        ...

    @staticmethod
    def sort_by_center_height(boxes,is_reverse=False):
        '''

        Args:
            boxes ():
            is_reverse ():

        Returns:

        '''
        ...

    @staticmethod
    def sort_by_distance(bboxes, imgcenter):
        ...

    def __lt__(self, other):
        '''

        Args:
            other ():

        Returns:

        '''
        ...

    @classmethod
    def sort_by_center_x(cls, bboxes):
        '''

        Args:
            bboxes ():

        Returns:

        '''
        ...


    @staticmethod
    def filter_bboxes_by_Inarea(bboxes, top_left,bottom_right,ratio):
        '''

        Args:
            bboxes ():
            top_left ():
            bottom_right ():
            ratio ():

        Returns:

        '''
        ...


    @staticmethod
    def sort_and_filter_points_by_ratio_in_img(boxes, img, width_ratio=0.5, height_ratio=0.5, is_show=False):
        '''

        Args:
            boxes ():
            img ():
            width_ratio ():
            height_ratio ():
            is_show ():

        Returns:

        '''
        ...


    @staticmethod
    def draw_remove_beyond_limit_area(img,bboxes,top_left,bottom_right,ratio=0.95):
        '''

        Args:
            img ():
            bboxes ():
            top_left ():
            bottom_right ():
            ratio ():

        Returns:

        '''
        ...

    @staticmethod
    def o3d_visualization(np_array_points):
        '''
        :param np_array_points: bboxes[0].point_cloud_region
        :return:
        '''

        ...





if __name__ == '__main__':

    bbox = RotatedBoundingBox(xywhr=(50, 50, 100, 100, 30), score=0.9, center_height=75)
    img = np.zeros((300, 300, 3), dtype=np.uint8)

    bbox.draw_rotated_box_with_center(img)

    cv2.imshow('Rotated Bounding Box', img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()




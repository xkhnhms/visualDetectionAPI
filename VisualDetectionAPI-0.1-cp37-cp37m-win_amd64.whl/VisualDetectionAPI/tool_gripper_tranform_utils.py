import numpy as np
from math import *
from scipy.spatial.transform import Rotation as R

def myRPY2R_robot(x, y, z):

    ...


def pose_robot(worldPose,is_m=True,is_angle=True):
    """

    Args:
        worldPose (List): x, y, z, Tx, Ty, Tz
        is_m (bool):
        is_angle (bool):

    Returns:

    """
    ...


def apply_gripper_rotation(T_end_base, T_gripper_end, rx_angle,axis='x'):
    """

    参数:
        T_end_base: 机械臂末端到基座的变换矩阵(4x4)。
        T_gripper_end: 夹爪到机械臂末端的变换矩阵(4x4)。
        rx_angle: 绕X轴旋转的角度(度)。

    返回:
        T_new_end_base: 更新后的机械臂末端到基座的变换矩阵。
    """
    ...


if __name__=='__main__':
    pass


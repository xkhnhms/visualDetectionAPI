import math
from scipy.interpolate import griddata
import cv2
import numpy as np
import open3d as o3d

class RotatedBoundingBox:
    def __init__(self, xywhr, score, label, center_height=None):
        """
       表示一个旋转边界框的对象。

       旋转边界框格式为 (center_x, center_y, width, height, rotation_angle)，其中：
       - (center_x, center_y) 是边界框中心坐标
       - width 和 height 分别是边界框的宽和高
       - rotation_angle 是绕中心点旋转的角度（单位：度或弧度，视具体模型而定）

       Args:
           xywhr (tuple or list of float): 旋转边界框参数，格式为 (center_x, center_y, width, height, rotation)
           score (float): 检测置信度分数，范围 [0, 1]
           label (str or int): 目标类别标签（字符串或整数）
           center_height (float or None, optional): 中心点高度信息（可用于三维空间定位），默认为 None
       """

        ...



    def print_variables(self):
        ...

    def draw_rotated_box(self, img, color=(0, 255, 0), thickness=2):
        ...

    def draw_rotated_box_with_center(self, img, color_box=(0, 255, 0), color_center=(0, 0, 255), thickness=2):
        ...

    def get_width_direction_vector(self):
        ...
    
    def get_side_distances(self, other_boxes):
        ...


    def get_min_side_gap(self, other_boxes):
        ...

    @staticmethod
    def sort_by_min_side_gap(boxes, descending=True):
        ...

    def calculate_mse_with(self, other_bbox):
        ...

    @staticmethod
    def find_best_match_by_bbox(current_bbox_pre, bbox_list):
        ...


    @staticmethod
    def draw_rotated_boxes(img,bboxes):
        ...

    def is_point_inside_by_step(self, px, py):
        ...


    def calculate_near_points_step(self, long_step, short_step):
        ...

    def is_point_inside(self, px, py):
        ...

    def calculate_near_points(self, near_x, near_y):
        ...

    def compute_normal_and_angle(self, isShow=False):
        ...

    def compute_normal_and_angle_with_gradient_v2(self, isShow=False):

        ...
    
    def compute_normal_and_angle_with_gradient_with_std(self, isShow=False):

        '''
        效果太差，放弃

        Args:
            isShow:

        Returns:

        '''
        ...

    def compute_normal_and_angle_with_gradient_base(self, isShow=False):

        ...

    def compute_normal_and_angle_with_gradient(self, isShow=False):

        ...

    def calculate_boundary_points(self):
        ...

    def create_mask(self, img_shape):
        ...

    def set_mask_region(self, img_shape):
        ...

    def extract_point_cloud_base(self, depth_frame, camera_intrinsics):
        ...

    def extract_point_cloud(self, depth_frame, camera_intrinsics, shrink_ratio=0.0):
        ...


    def extract_point_cloud_by_lr(self, depth_frame, camera_intrinsics,flag='left,right'):
        ...

    def extract_point_cloud_region(self, point_cloud):
        ...

    def extract_point_cloud_region_with_shrink(self, point_cloud, shrink_ratio=0.0):
        ...


    def extract_rgb_rotated_region(self, img, visualize=True):
        ...

    def extract_and_visualize_rgb_region(self, img, visualize=True):
        """
        根据旋转矩形框的xywhr参数提取该区域的RGB图像并进行可视化
        :param img: 输入的原始RGB图像
        :param visualize: 是否可视化提取出的区域
        :return: 提取出的旋转矩形框对应的RGB图像区域

        note: 有問題，暫停使用
        """
        ...

    def is_center_in_quarter_area(self, img_shape,quarter_ratio_x=0.75,quarter_ratio_y=0.75):
        """
        判断当前边界框的中心点是否位于图像左上角指定比例区域之外。

        此方法常用于判断目标是否出现在图像的边缘区域（如只关注图像中央区域的目标）。
        默认判断是否在图像左上角 3/4 区域以外（即：若中心在左上 3/4 区域内 → 返回 False）。

        Args:
            img_shape (Tuple[int, int]): 图像的尺寸，格式为 (height, width)
            quarter_ratio_x (float, optional): 图像宽度方向上的阈值比例，默认为 0.75（即左侧 75%）
            quarter_ratio_y (float, optional): 图像高度方向上的阈值比例，默认为 0.75（即上侧 75%）

        Returns:
            bool: 如果边界框的中心点位于指定区域外（右侧或下侧），返回 True；否则返回 False

        """
        ...

    def is_center_in_specified_area(self, top_left, bottom_right, proportion):
        ...

    def is_rotation_within_angle_range(self, min_angle, max_angle):
        # Normalize the angles to be within 0 to 360 degrees
        ...

    @staticmethod
    def filter_bboxes_by_angle_range(bboxes, min_angle, max_angle):
        ...

    def get_properties(self):
        ...

    @staticmethod
    def append_boxes(boxes):
        ...

    @staticmethod
    def append_boxes2(boxes):
        ...

    @staticmethod
    def sort_by_score(boxes):
        ...

    @staticmethod
    def sort_by_center_height(boxes,is_reverse=False):
        ...

    @staticmethod
    def sort_by_distance(bboxes, imgcenter):
        ...

    def __lt__(self, other):
        ...

    @classmethod
    def sort_by_center_x(cls, bboxes):
        ...


    @staticmethod
    def filter_bboxes_by_Inarea(bboxes, top_left,bottom_right,ratio):
        ...

    @staticmethod
    def sort_and_filter_points_by_ratio_in_img_base(bboxes, img_shape, max_distance_ratio):
        ...

    @staticmethod
    def sort_and_filter_points_by_ratio_in_img_base2(bboxes, img_shape,  max_width_ratio, max_height_ratio):
        '''

        :param bboxes:
        :param img_shape:
        :param max_width_ratio:
        :param max_height_ratio:
        :return:

        功能不滿足需求，停用

        '''
        ...

    @staticmethod
    def sort_and_filter_points_by_ratio_in_img(boxes, img, width_ratio=0.5, height_ratio=0.5, is_show=False):
        ...


    @staticmethod
    def draw_remove_beyond_limit_area(img,bboxes,top_left,bottom_right,ratio=0.95):
        ...

    @staticmethod
    def o3d_visualization(np_array_points):
        '''
        :param np_array_points: bboxes[0].point_cloud_region
        :return:
        '''

        ...





if __name__ == '__main__':
    # 示例使用
    bbox = RotatedBoundingBox(xywhr=(50, 50, 100, 100, 30), score=0.9, center_height=75)

    # 创建一个空白图像
    img = np.zeros((300, 300, 3), dtype=np.uint8)

    bbox.draw_rotated_box_with_center(img)

    # 显示图像
    cv2.imshow('Rotated Bounding Box', img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()




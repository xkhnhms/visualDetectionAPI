import os
from PIL import Image
from torch.utils.data import Dataset
from torchvision.transforms import ToTensor
from torch import tensor

import torch.nn as nn

import time
import torch
import logging
import argparse

from tqdm import tqdm
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

logger = logging.getLogger(__name__)

class classifier(nn.Module):
    def __init__(self, img_size=224, input_channel=3, num_class=3):
        super().__init__()

        pass

class LoadDataset(Dataset):
    def __init__(self, type, img_size, data_dir,classifier_names):

       pass


def train_classifier(
        train_path,
        test_path,
        classifier_names,
        checkpoint_path='checkpoint',
        batch_size=8,
        epochs=200,
        img_size=128,
        milestones=[0.5, 0.8, 0.9],
        warm=1,
        lr=1e-4,
        tensorboard=False

    ):

    pass
        

if __name__ == '__main__':
    train_classifier(
        train_path='/train',
        test_path='',

        batch_size=8,
        epochs=200,
        classifier_names=["8_1", "8_2"],

        checkpoint_path='checkpoint',

        img_size=128,
        milestones=[0.5, 0.8, 0.9],
        warm=1,
        lr=1e-4,
        tensorboard=False

    )
















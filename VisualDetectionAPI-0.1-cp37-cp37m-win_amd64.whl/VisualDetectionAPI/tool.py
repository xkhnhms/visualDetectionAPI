import json
import logging
import math
import os
import threading
import time

import cv2
import open3d as o3d
from scipy.spatial.transform import Rotation as Rot
from scipy.spatial.transform import Rotation as R
import numpy as np
import matplotlib.pyplot as plt

from scipy.interpolate import griddata
import numpy as np
from math import *


class CameraInfo():
    def __init__(self, width, height, fx, fy, cx, cy, scale):
        """

        Args:
            width ():
            height ():
            fx ():
            fy ():
            cx ():
            cy ():
            scale ():
        """
        ...

def create_point_cloud_from_depth_image(depth, camera, organized=True):

    ...

def myRPY2R_robot(x, y, z):
    ...

def pose_robot(worldPose,is_m=True,is_angle=True):
    """

    Args:
        worldPose (List): x, y, z, Tx, Ty, Tz
        is_m (bool):
        is_angle (bool):

    Returns:

    """
    ...


def extract_point_cloud_in_region(point_cloud, x1, y1, x2, y2):
    ...



def save_origin_roi_pointCloud_files(color_image,validPoints,ROIs,root_dir='saveDatas'):
    """

    Args:
        color_image ():
        validPoints ():
        ROIs ():
        root_dir ():

    Returns:

    """
    ...


def knn_cluster(clean_point_cloud,eps = 0.05,min_points = 60,min_cluster_size = 1100):
    ...


def depthMeasure(roi,validPoints,flag=0):
    ...


def depth_measure_point_cloud(region_points):

    ...


def getDualArmCameraWorldPose(center_x,center_y,mean_height,K):

    ...



def transformDualArmEyeIn(camera_pose,cert_pose,calibMatrix):

    ...

def transformDualArmEyeTo(camera_pose,calibMatrix):

    ...



def is_point_in_rect(point, rect):

    ...



def filter_obj_flag(ROIs,flag):
    ...


class MyThread(threading.Thread):
    ...


def draw_rectangle_on_image(img, top_left, bottom_right):
    ...


def slope_to_angle(slope):
    ...


def findSlope(color_image):
    ...

if __name__=='__main__':
    pass



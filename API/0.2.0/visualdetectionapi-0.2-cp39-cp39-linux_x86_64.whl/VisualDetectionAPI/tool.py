import json
import logging
import math
import os
import threading
import time

import cv2
import open3d as o3d
from scipy.spatial.transform import Rotation as Rot
from scipy.spatial.transform import Rotation as R
import numpy as np
import matplotlib.pyplot as plt

from scipy.interpolate import griddata
import numpy as np
from math import *


class CameraInfo():
    def __init__(self, width, height, fx, fy, cx, cy, scale):
        """

        Args:
            width ():
            height ():
            fx ():
            fy ():
            cx ():
            cy ():
            scale ():
        """
        ...

def create_point_cloud_from_depth_image(depth, camera, organized=True):
    '''

    Args:
        depth ():
        camera ():
        organized ():

    Returns:

    '''

    ...

def myRPY2R_robot(x, y, z):
    '''

    Args:
        x ():
        y ():
        z ():

    Returns:

    '''
    ...

def pose_robot(worldPose,is_m=True,is_angle=True):
    """

    Args:
        worldPose (List): x, y, z, Tx, Ty, Tz
        is_m (bool):
        is_angle (bool):

    Returns:

    """
    ...


def extract_point_cloud_in_region(point_cloud, x1, y1, x2, y2):
    '''

    Args:
        point_cloud ():
        x1 ():
        y1 ():
        x2 ():
        y2 ():

    Returns:

    '''
    ...



def save_origin_roi_pointCloud_files(color_image,validPoints,ROIs,root_dir='saveDatas'):
    """

    Args:
        color_image ():
        validPoints ():
        ROIs ():
        root_dir ():

    Returns:

    """
    ...


def knn_cluster(clean_point_cloud,eps = 0.05,min_points = 60,min_cluster_size = 1100):
    '''

    Args:
        clean_point_cloud ():
        eps ():
        min_points ():
        min_cluster_size ():

    Returns:

    '''
    ...


def depthMeasure(roi,validPoints,flag=0):
    '''

    Args:
        roi ():
        validPoints ():
        flag ():

    Returns:

    '''
    ...


def depth_measure_point_cloud(region_points):
    '''

    Args:
        region_points ():

    Returns:

    '''

    ...


def getDualArmCameraWorldPose(center_x,center_y,mean_height,K):
    '''

    Args:
        center_x ():
        center_y ():
        mean_height ():
        K ():

    Returns:

    '''

    ...



def transformDualArmEyeIn(camera_pose,cert_pose,calibMatrix):
    '''

    Args:
        camera_pose ():
        cert_pose ():
        calibMatrix ():

    Returns:

    '''

    ...

def transformDualArmEyeTo(camera_pose,calibMatrix):
    '''

    Args:
        camera_pose ():
        calibMatrix ():

    Returns:

    '''

    ...



def is_point_in_rect(point, rect):
    '''

    Args:
        point ():
        rect ():

    Returns:

    '''

    ...



def filter_obj_flag(ROIs,flag):
    '''

    Args:
        ROIs ():
        flag ():

    Returns:

    '''
    ...


class MyThread(threading.Thread):
    ...


def draw_rectangle_on_image(img, top_left, bottom_right):
    '''

    Args:
        img ():
        top_left ():
        bottom_right ():

    Returns:

    '''
    ...


def slope_to_angle(slope):
    ...


def findSlope(color_image):
    '''

    Args:
        color_image ():

    Returns:

    '''
    ...

if __name__=='__main__':
    pass


